package FeatherC;

import java.util.HashMap;
import java.util.Vector;

class FCEvalValuator
    extends FCValuator
{
    private int blockLevel = -1; // -1: globalEnv
    //    private HashMap globalEnv;
    private Vector localEnv;

    public FCEvalValuator(CircularBuffer b, FCParser p)
    {
	super(b, p);
	//	globalEnv = new HashMap();
	localEnv = new Vector();
    }

    public void visit(FCAritTerm e) 
    {
	res.add(new Integer((int)e.value));
    }
    public void visit(FCBoolTerm e)
    {
	res.add(new Integer(e.value? 1: 0));
    }
    public void visit(FCLessExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() < rres.intValue()? 1: 0));
    }
    public void visit(FCLessEqualExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() <= rres.intValue()? 1: 0));
    }
    public void visit(FCGreaterExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() > rres.intValue()? 1: 0));
    }
    public void visit(FCGreaterEqualExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() >= rres.intValue()? 1: 0));
    }
    public void visit(FCEqualExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() == rres.intValue()? 1: 0));
    }
    public void visit(FCDifferentExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() != rres.intValue()? 1: 0));
    }
    public void visit(FCPlusExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() + rres.intValue()));
    }
    public void visit(FCMinusExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() - rres.intValue()));
    }
    public void visit(FCTimesExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() * rres.intValue()));
    }
    public void visit(FCDivideExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() / rres.intValue()));
    }
    public void visit(FCModExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() % rres.intValue()));
    }
    public void visit(FCAndExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() == 1 && rres.intValue() == 1 ?
			   1: 0));
    }
    public void visit(FCOrExp e)
    {
	e.left.accept(this); 
	Integer lres = (Integer) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();
	res.add(new Integer(lres.intValue() == 1 || rres.intValue() == 1?
			   1: 0));
    }
    public void visit(FCNotExp e)
    {
	e.arg.accept(this);
	res.add(new Integer(((Integer)getRes()).intValue() == 0 ? 1: 0));
    }
    public void visit(FCAssignExp e)
    {
	HashMap currentEnv;

	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();

	Integer d = null;
	HashMap environment = null;
	int i;
	for (i = blockLevel; i >= -1; i--) {
	    environment = (HashMap) ((i == -1)? globalEnv: localEnv.get(i));
	    if (environment.containsKey(lres))
		break;
	}

	if (i >= -1) {
	    res.add(rres);
	    //	    environment.put(lres, rres);
	    environment.put(lres, new 
			Ident(rres, ((Ident)environment.get(lres)).getType()));
	}	
	else {
	    /*System.err.println("(FCAssignExp) Unable to resolve symbol '" + 
	      lres +"'");*/
	    errorMsgs += "Unable to resolve symbol '" + lres + "'";
	    parser.stop = true;
	    stop = true;
	    errors++;
	}
    }
    public void visit(FCDeclExp e)
    {
	HashMap currentEnv;

	// System.err.println("In visit FCDeclExp");

	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	Integer rres = (Integer) getRes();

	if (blockLevel == -1)
	    currentEnv = globalEnv;
	else
	    currentEnv = (HashMap) localEnv.get(blockLevel);

	if (currentEnv.containsKey(lres)) {
	    //throw new FCEvalException("Already defined symbol " + lres, e);
	    errorMsgs += "Already defined symbol '" + lres + "'";
	    parser.stop = true;
	    stop = true;
	    errors++;
	}
	
	//	currentEnv.put(lres, rres);
	currentEnv.put(lres, new Ident(rres, e.type));
	res.add(rres);
    }
    public void visit(FCIdentTerm e)
    {
	res.add(new String(e.name));
    }
    public void visit(FCIdentVal e)
    {
	int i;
	Integer d = null;

	for (i = blockLevel; i >= -1; i--) {
	    HashMap environment = (HashMap) ((i == -1)? globalEnv:
		localEnv.get(i));
	    //	    System.out.println(environment);
	    //Integer d = (Integer) environment.get(e.name);
	    //d = (Integer) environment.get(e.name);
	    Ident id = (Ident) environment.get(e.name);
	    if (id != null)
		d = (Integer) id.getValue();
	    /*	    if (d == null)
		    continue;
		    
		    res = new Integer(((Integer)environment.get(e.name)).intValue());
		    if (res != null)
		    break;
		    
		    res = new Integer(d.intValue());
		    break;*/
	    if (d != null)
		break;
	}

	if (d != null) // equivale a: if (i >= -1)
	    res.add(new Integer(d.intValue()));
	else {
	    /*FCGeneral.emitError(e, "(FCIdentVal) Unable to resolve symbol '" + 
	      e.name + "'");*/
	    errorMsgs += "Unable to resolve symbol '" + e.name + "'";
	    parser.stop = true;
	    stop = true;
	    errors++;
	}
    }
    public void visit(FCBlockExp e)
    {
	int i;
	FCExp curExp;

	blockLevel++;
	localEnv.add(new HashMap());

	//System.out.println("blocco.statement");
	for (i = 0; i < e.statements.size(); i++) {
	    curExp = (FCExp) e.statements.elementAt(i);
	    curExp.accept(this);
	    if (FCOptions.debugEval) 
		System.out.println(blockLevel+ "." + i + ": " + res);
	}
    

	localEnv.remove(blockLevel);
	blockLevel--;
    }
    public void visit(FCIfExp e)
    {
	e.condition.accept(this);
	int d = ((Integer)getRes()).intValue();
	if (d != 0) {
	    e.action.accept(this);
	}
	else if (e.elseStatement != null) {
	    e.elseStatement.accept(this);
	}
    }
    public void visit(FCWhileExp e)
    {
	e.condition.accept(this);
	int d = ((Integer)getRes()).intValue();
	while (d != 0) {
	    e.action.accept(this);
	    e.condition.accept(this);
	    d = ((Integer)getRes()).intValue();
	}
    }

    public void formatEvaluations() {}
}

class Ident
{
    private Object value;
    private String type;

    Ident(Object value, String type)
    {
	this.value = value;
	this.type = type;
    }

    String getType() {return type;}
    Object getValue() {return value;}
}
	
