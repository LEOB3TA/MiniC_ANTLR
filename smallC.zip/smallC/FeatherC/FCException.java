package FeatherC;

class FCException
    extends Exception 
{
    FCException()
    {
	super("Error while parsing");
    }

     FCException(String msg) 
    {
	super(msg);
    }
}

class FCParserException
    extends FCException
{
    FCParserException() { super();}

    FCParserException(String msg) { super(msg); }

    FCParserException(String msg, FCToken token)
    {
	super(FCGeneral.currentFile + ":" + token.lineno + ": " +
	      msg + " (" + token.name +")" + 
	      ((FCGeneral.currentLine != null) ? "\n\t" + FCGeneral.currentLine:
	       ""));
    }
}

class FCStopParsingException
    extends FCParserException
{
}

class FCEvalException
    extends FCException
{
    FCEvalException() { super();}

    FCEvalException(String msg) { super(msg); }

    FCEvalException(String msg, FCExp exp)
    {
	super(FCGeneral.currentFile + ": " + msg + " (" + exp + ")");

    }
}

class FCEndOfTokensException
    extends FCException
{
    FCEndOfTokensException()
    {
	super("No more tokens");
    }
}

class FCNullTokenException
    extends FCException
{
    FCNullTokenException() 
    {
	super("Null token found");
    }
}
