package FeatherC;


import java.io.StreamTokenizer;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

/**
 * Classe astratta che deve essere estesa dai lexer per SmallC<br>
 * <br>
 * In generale, ogni lexer<br>
 * <ul>
 *     <li>� associato ad un thread</li>
 *     <li>inserisce i token generati in un buffer condiviso con il parser</li>
 *     <li>esce quando incontra la fine del file o si verifica un errore</li>
 * </ul>
 */
public abstract class FCLexer
    extends Thread
{
    private CircularBuffer buffer;
    protected BufferedReader in; // solo per debug (copia del reader di input)
    boolean stop = false;
    int errors = 0;
    String errorMsgs = "";

    /**
     * @param buffer il buffer condiviso con il parser
     */
    FCLexer(CircularBuffer buffer) {
	super("Lexer");
	
	assert buffer != null;
	this.buffer = buffer;
	if (FCGeneral.currentFile != null) 
	    try {
		in = new BufferedReader(new FileReader(FCGeneral.currentFile));
	    } catch (java.io.IOException e) {in = null;}
    }

    /**
     * @return il numero di errori trovati dal lexer
     */
    public int getErrors() { return errors;}

    /**
     * @return una stringa contenente la descrizione degli errori trovati
     */
    public String getErrorMsgs() { return errorMsgs; }

    /**
     * imposta lo stream di input
     */
    abstract public void setInput(java.io.Reader in);

    /**
     * @return il token successivo, null in caso di errore o EOF
     */
    abstract public FCToken nextToken()
	throws java.io.IOException;

    /**
     * controlla che il token sia ammissibile
     */
    abstract public boolean checkToken(FCToken token);


    /**
     * Il comportamente predefinito del lexer �:
     *
     * recupera il prossimo token con  nextToken
     * fa' un sanity check sul token ottenuto tramite checkToken
     * inserisci il token nel buffer
     *
     * Se si � verificato un errore o si � esaurito lo stream di ingresso:
     * inserisci un token di tipo FCLastToken nel buffer
     * notifica il parser
     * esci
     */
    public void run()
    {
	int i = 0;
	
	try {
	    FCToken token = nextToken();
	    
	    while (token != null && !stop) {
		if (FCOptions.debugToken)
		    System.out.println(token);
		if (!checkToken(token)) {
		    errors++;
		    break;
		}
		buffer.put(token);
		token = nextToken();
	    }
	    buffer.put(new FCLastToken());

	    synchronized(buffer) {
		buffer.notifyAll();
	    }
	    
	} catch (java.io.IOException e) { System.err.println(e); }

	if (FCOptions.debugThread)
	    System.out.println("Lexer exiting...");
    }
}
