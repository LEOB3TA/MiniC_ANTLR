package FeatherC;


class FCOptions 
{
    static boolean debugCircularBuffer = false;
    static boolean debugToken = false;
    static boolean debugParsing = false;
    static boolean debugThread = false;
    static boolean debugEval = false;
}

class FCGeneral
{
    static String currentFile = null;
    static String currentLine = null;
    static long currentLineNo = 0;

   public static void emitError(FCToken tok, String msg)
    {
	String lineno = (tok != null) ? "" + tok.lineno : "?";
	String name   = (tok != null) ? tok.name   : "null token";

	System.err.println(currentFile + ":" + lineno + ": " +
			   msg + " (" + name + ")" + 
			   ((FCGeneral.currentLine != null) ? "\n" + 
			   FCGeneral.currentLine : ""));
    }

    public static void emitError(FCExp exp, String msg)
    {
	System.err.println(currentFile + ":" + msg + "\n\t" + exp);
	System.exit(1);
    }
}
