package FeatherC;

import java.util.Vector;

abstract class FCExp 
{
    abstract void accept(IFCVisitor v);
}

class FCLastExp
    extends FCExp
{
    public String toString() {return "LAST_EXP";}
    public void accept(IFCVisitor v) {}
}

class FCEmptyExp
    extends FCExp
{
    public String toString() { return "EMPTY_EXP";}
    public void accept(IFCVisitor v) {}
}

class FCBlockExp
    extends FCExp
{
    Vector statements;

    public FCBlockExp() 
    {
	statements = new Vector();
    }

    public void accept(IFCVisitor v) {v.visit(this);}
    public String toString() {
	String res = "";
	int i;

	res = "{\n";
	for (i = 0; i < statements.size()-1; i++)
	    res = res + statements.elementAt(i) + "\n";
	res = res + statements.elementAt(i) + "\n}";

	return res;
    }
    
    public FCExp get(int index) 
    { 
	return (FCExp) statements.elementAt(index);
    }

    public void add(FCExp exp)
    {
	statements.add(exp);
    }
}

class FCIfExp
    extends FCExp
{
    FCExp condition;
    FCExp action = null;
    FCExp elseStatement = null;

    public FCIfExp(FCExp condition) {
	this.condition = condition;
    }

    public void accept(IFCVisitor v) {v.visit(this);}

    public String toString() {
	return "if (" + condition + ")\n" + action +
	    ((elseStatement == null) ? "" : elseStatement.toString());
    }
    
    void setAction(FCExp action) {
	this.action = action;
    }

    void setElseStatement(FCExp elseStatement) {
	this.elseStatement = elseStatement;
    }
}

class FCWhileExp
    extends FCExp
{
    FCExp condition;
    FCExp action = null;

    public FCWhileExp(FCExp condition) {
	this.condition = condition;
    }

    public void accept(IFCVisitor v) {v.visit(this);}

    public String toString() {
	return "while (" + condition + ")\n" + action;
    }

    void setAction(FCExp action) {
	this.action = action;
    }
}

class FCAritTerm
    extends FCExp
{
    double value;

    public FCAritTerm(double value) {
	this.value = value;
	
	if (FCOptions.debugParsing)
	    System.out.println("ARIT expr");
    }

    public String toString() { return "" + value;}
    public double getValue() {return value;}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCBoolTerm
    extends FCExp
{
    boolean value;

    public FCBoolTerm(boolean value) 
    {
	this.value = value;
	if (FCOptions.debugParsing)
	    System.out.println("BOOL expr");
    }

    public FCBoolTerm(String value) {
	assert value.equals("true") || value.equals("false");

	if (value.equals("true"))
	    this.value = true;
	else
	    this.value = false;

	if (FCOptions.debugParsing)
	    System.out.println("BOOL expr");
    }

    public FCBoolTerm(int value) {
	if (value != 0)
	    this.value = true;
	else 
	    this.value = false;

	if (FCOptions.debugParsing)
	    System.out.println("BOOL expr");
    }

    public String toString() {return "" + value;}
    public boolean getValue() {return value; }
    public void accept(IFCVisitor v) {v.visit(this);}
}


abstract class FCBinOpExp 
    extends FCExp
{
    FCExp left, right;

    FCBinOpExp(FCExp left, FCExp right) 
    {
	this.left = left;
	this.right = right;
    }

    abstract String getOp();

    public String toString() 
    {
	return "(" + left + getOp() + right + ")";
    }
    //   public void accept(IFCVisitor v) {v.visit(this);}

}

class FCLessExp
    extends FCBinOpExp
{
    public FCLessExp(FCExp l, FCExp r) {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("LESS expr");
    }

    String getOp() {return "<";};
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCLessEqualExp
    extends FCBinOpExp
{
    public FCLessEqualExp(FCExp l, FCExp r) {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("LESS_EQUAL expr");
    }

    String getOp() {return "<=";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCGreaterExp
    extends FCBinOpExp
{
    public FCGreaterExp(FCExp l, FCExp r) {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("GREATER expr");
    }

    String getOp() {return ">";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCGreaterEqualExp
    extends FCBinOpExp
{
    public FCGreaterEqualExp(FCExp l, FCExp r) {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("GREATER_EQUAL expr");
    }

    String getOp() {return ">=";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCEqualExp
    extends FCBinOpExp
{
    public FCEqualExp(FCExp l, FCExp r) {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("EQUAL expr");
    }

    String getOp() {return "==";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCDifferentExp
    extends FCBinOpExp
{
    public FCDifferentExp(FCExp l, FCExp r) {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("DIFFERENT expr");
    }

    String getOp() {return "!=";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCPlusExp
    extends FCBinOpExp
{
    public FCPlusExp(FCExp l, FCExp r)
    {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("PLUS expr");
    }

    String getOp() {return "+"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCMinusExp
    extends FCBinOpExp
{
    public FCMinusExp(FCExp l, FCExp r)
    {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("MINUS expr");
    }

    String getOp() {return "-"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}   

class FCTimesExp
    extends FCBinOpExp
{
    public FCTimesExp(FCExp l, FCExp r)
    {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("TIMES expr");
    }

    String getOp() {return "*"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}   

class FCDivideExp
    extends FCBinOpExp
{
    public FCDivideExp(FCExp l, FCExp r)
    {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("DIVIDE expr");
    }

    String getOp() {return "/"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}   

class FCModExp
    extends FCBinOpExp
{
    public FCModExp(FCExp l, FCExp r)
    {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("MOD expr");
    }

    String getOp() {return "%"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}   

class FCAndExp 
    extends FCBinOpExp
{
    public FCAndExp(FCExp l, FCExp r) 
    {
	super(l, r); 
	if (FCOptions.debugParsing)
	    System.out.println("AND expr");
    }
    
    String getOp() {return "&&"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCOrExp
    extends FCBinOpExp
{
    public FCOrExp(FCExp l, FCExp r) 
    { 
	super(l, r); 
    	if (FCOptions.debugParsing)
	    System.out.println("OR expr");
    }

    String getOp() { return "||"; }
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCAssignExp
    extends FCBinOpExp
{
    public FCAssignExp(FCExp l, FCExp r)
    {
	super(l, r);
	if (FCOptions.debugParsing)
	    System.out.println("ASSIGN expr");
    }

    String getOp() {return "=";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCDeclExp
    extends FCAssignExp
{
    String type;

    public FCDeclExp(FCExp l, FCExp r)
    {
	super(l, r);

	if (FCOptions.debugParsing)
	    System.out.println("DECL expr");
    }	
    public void accept(IFCVisitor v) {v.visit(this);}
}


abstract class FCMonOpExp
    extends FCExp
{
    FCExp arg;

    FCMonOpExp(FCExp arg) { this.arg = arg; }
    
    abstract String getOp();
    public String toString() {return getOp() + "(" + arg + ")";}
}

class FCNotExp 
    extends FCMonOpExp
{
    public FCNotExp(FCExp arg) 
    {
	super(arg);
	if (FCOptions.debugParsing)
	    System.out.println("NOT expr");
    }

    String getOp() {return "!";}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCIdentTerm
    extends FCExp
{
    String name;

    public FCIdentTerm(String name) 
    {
	this.name = name;
    }

    public String toString() { return name; }
    String getName() {return name;}
    public void accept(IFCVisitor v) {v.visit(this);}
}

class FCIdentVal
    extends FCIdentTerm
{
    public FCIdentVal(String name) 
    {
	super(name);
    }
    public void accept(IFCVisitor v) {v.visit(this);}
}

/**
 * In generale, il parser:
 * <ul>
 *     <li>� associato ad un thread</li>
 *     <li>estrae i token dal buffer condiviso con il lexer</li>
 *     <li>inserisce le espressioni generate in un buffer condiviso con il valutatore</li>
 *     <li>esce quando incontra la fine del file o si verifica un errore</li>
 * </ul>
 */
public class FCParser
    extends Thread
{
    private CircularBuffer bufferTok;
    private CircularBuffer bufferExp;
    private FCToken currentToken = null;
    private boolean disallowMinus = false;
    private boolean endDeclarations = false;
    private int errors = 0;
    private String errorMsgs = "";
    boolean stop = false;
    private FCLexer lexer;

    /**
     * @param bufferTok il buffer condiviso con il lexer
     * @param bufferExp il buffer condiviso con il valutatore
     * @param lexer il lexer
     */
    FCParser(CircularBuffer bufferTok, CircularBuffer bufferExp, 
	     FCLexer lexer) {
	super("Parser");

	assert bufferTok != null && bufferExp != null && lexer != null;

	this.lexer = lexer;
	this.bufferTok = bufferTok;
	this.bufferExp = bufferExp;
    }

    /**
     * @return il numero di errori ravvisati dal parser
     */
    public int getErrors() { return errors;}

    /**
     * @return restituisce una stringa contenente la descrizione degli errori trovati
     */
    public String getErrorMsgs() { return errorMsgs;}

    /**
     * Recupera il prossimo token dal buffer e effettua alcuni check di manutenzione
     *
     * @return il token recuperato
     */
    private FCToken getNextToken()
	throws FCException
    {
	if (currentToken != null)
	    disallowMinus = (currentToken.type == FCTokenType.OPERATOR &&
			     (currentToken.name.equals("+") ||
			      currentToken.name.equals("-") ||
			      currentToken.name.equals("*") ||
			      currentToken.name.equals("/")))?
		true : false;
	
	FCToken token = (FCToken) bufferTok.get();

	if (token == null) {
	    throw new FCNullTokenException();
	}
	/*	if (token instanceof FCLastToken) {
		throw new FCStopParsingException();
		}
	*/
	    
	
	return token;
    }


    FCExp parseE0()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE0(): " + currentToken);

	FCExp e1Seq = parseE1();
	if (e1Seq == null)
	    return null;

	while(true) {
	    if (currentToken.type == FCTokenType.OPERATOR &&
		currentToken.name.equals("=")) {
		currentToken = getNextToken();
		FCExp nextSeq = null;
		if ((nextSeq = parseE0()) == null)
		    throw new 
			FCParserException("Missing expected right hand side " +
					  "of assign expression",
					  currentToken);
		else if (e1Seq instanceof FCIdentVal)
		    // lvalue � FCIdentTerm, rvalue � FCIdentVal
		    e1Seq = new FCAssignExp(new FCIdentTerm(((FCIdentVal)e1Seq).name), nextSeq);
		else
		{
		    throw new 
			FCParserException("Illegal right hand side of assign" +
					  "expression", currentToken);
		}   
		// System.out.println("nextSeq e' " + nextSeq.getClass());
	    }
	    else
		break;
	}

	return e1Seq;
    }

    FCExp parseE1() 
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE1(): " + currentToken);

	FCExp e2Seq = parseE2();
	if (e2Seq == null)
	    return null;

	while (true)
	    if (currentToken.type == FCTokenType.OPERATOR &&
		currentToken.name.equals("||")) {
		currentToken = getNextToken();
		FCExp nextSeq = null;
		if ((nextSeq = parseE2()) == null) {
		    throw new 
			FCParserException("Illegal start of OR expression",
					  currentToken);
		}
		e2Seq = new FCOrExp(e2Seq, nextSeq);
	    }
	    else
		break;
	
	return e2Seq;
    }

    FCExp parseE2() 
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE2(): " + currentToken);

	FCExp e3Seq = parseE3();
	if (e3Seq == null)
	    return null;

	while (true) {
	    if (currentToken.type == FCTokenType.OPERATOR &&
		currentToken.name.equals("&&")) { // found '&&'
		currentToken = getNextToken();
		FCExp nextSeq = null;
		if ((nextSeq = parseE3()) == null) {
		    throw new
			FCParserException("Illegal start of AND expression",
					  currentToken);
		}
		e3Seq = new FCAndExp(e3Seq, nextSeq);
	    }
	    else 
		break;
	}

	return e3Seq;
    }

    FCExp parseE3()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE3(): " + currentToken);

	FCExp e4Seq = parseE4();
	if (e4Seq == null)
	    return null;

	if (currentToken.type == FCTokenType.OPERATOR) {
	    FCExp nextSeq = null;
	    if (currentToken.name.equals("<")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE4()) == null) {
		    throw new 
			FCParserException("Illegal start of LESS expression",
					  currentToken);
		}
		e4Seq = new FCLessExp(e4Seq, nextSeq);
	    }
	    else if (currentToken.name.equals("<=")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE4()) == null) {
		    throw new 
			FCParserException("Illegal start of LESS_EQUAL expression",
					  currentToken);
		}
		e4Seq = new FCLessEqualExp(e4Seq, nextSeq);
	    }
	    else if (currentToken.name.equals(">")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE4()) == null) {
		    throw new 
			FCParserException("Illegal start of GREATER expression",
					  currentToken);
		}
		e4Seq = new FCGreaterExp(e4Seq, nextSeq);
	    }
	    else if (currentToken.name.equals(">=")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE4()) == null) {
		    throw new 
			FCParserException("Illegal start of GREATER_EQUAL expression",
					  currentToken);
		}
		e4Seq = new FCGreaterEqualExp(e4Seq, nextSeq);
	    }		
	    else if (currentToken.name.equals("==")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE4()) == null) {
		    throw new 
			FCParserException("Illegal start of EQUAL expression",
					  currentToken);
		}
		e4Seq = new FCEqualExp(e4Seq, nextSeq);
	    }		
	    else if (currentToken.name.equals("!=")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE4()) == null) {
		    throw new 
			FCParserException("Illegal start of DIFFERENT expression",
					  currentToken);

		}
		e4Seq = new FCDifferentExp(e4Seq, nextSeq);
	    }		
	}
	
	return e4Seq;
    }

    FCExp parseE4()
	throws FCException, FCParserException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE4(): " + currentToken);
	
	FCExp e5Seq = parseE5();
	if (e5Seq == null)
	    return null;

	while(currentToken.type == FCTokenType.OPERATOR) {
	    FCExp nextSeq = null;

	    if(currentToken.name.equals("+")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE5()) == null) {
		    throw new
			FCParserException("Illegal start of PLUS expression",
					  currentToken);
		}
		e5Seq = new FCPlusExp(e5Seq, nextSeq);
	    }
	    else if (currentToken.name.equals("-")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE5()) == null) {
		    throw new
			FCParserException("Illegal start of MINUS expression",
					  currentToken);
		}
		e5Seq = new FCMinusExp(e5Seq, nextSeq);
	    }
	    else
		break;
	}
	
	return e5Seq;
    }
    
    FCExp parseE5() 
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE5(): " + currentToken);
	
	FCExp e6Seq = parseE6();
	if (e6Seq == null)
	    return null;

	while (currentToken.type == FCTokenType.OPERATOR) {
	    FCExp nextSeq = null;

	    if (currentToken.name.equals("*")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE6()) == null) {
		    throw new
			FCParserException("Illegal start of TIMES expression",
					  currentToken);
		}
		e6Seq = new FCTimesExp(e6Seq, nextSeq);
	    }
	    else if (currentToken.name.equals("/")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE6()) == null) {
		    		    throw new
			FCParserException("Illegal start of DIVIDE expression",
					  currentToken);
		}		    
		e6Seq = new FCDivideExp(e6Seq, nextSeq);
	    }
	    else if (currentToken.name.equals("%")) {
		currentToken = getNextToken();
		if ((nextSeq = parseE6()) == null) {
		    throw new
			FCParserException("Illegal start of MOD expression",
					  currentToken);
		}		    
		e6Seq = new FCModExp(e6Seq, nextSeq);
	    }
	    else 
		break;
	}
	return e6Seq;
    }

    FCExp parseE6()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseE6(): " + currentToken);
	
	    while (currentToken.type == FCTokenType.OPERATOR &&
		currentToken.name.equals("!")) {
		currentToken = getNextToken();
		return new FCNotExp(parseE6());
	    }
	
	return parseTerm();

    }

    FCExp parseTerm()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseTerm(): " + currentToken);

	FCExp exp = null;
	
	if (currentToken.type == FCTokenType.SEPARATOR &&
	    currentToken.name.equals("(")) {
	    currentToken = getNextToken();
	    exp = parseE0();
	    if (currentToken.name.equals(")")) {
		currentToken = getNextToken();
		return exp;
	    }
	    else 
		throw new FCParserException("Missing expected ')'", 
					    currentToken); 
	}

	/*	else if (currentToken.type == FCTokenType.SEPARATOR &&
	    currentToken.name.equals("{")) {
	    assert (false);
	    exp = parseBlock();
	}*/
	else if (currentToken.type == FCTokenType.BOOLLITERAL) {
	    exp = new FCBoolTerm(currentToken.name);
	    currentToken = getNextToken();
	}
	else if (currentToken.type == FCTokenType.FLOATLITERAL ||
		 currentToken.type == FCTokenType.INTLITERAL) {
	    exp = new FCAritTerm(currentToken.dvalue);
	    currentToken = getNextToken();
	}
	else if (currentToken.type == FCTokenType.IDENT) {
	    exp = new FCIdentVal(currentToken.name);
	    currentToken = getNextToken();
	}
	else if (currentToken.type == FCTokenType.OPERATOR &&
		 currentToken.name.equals("-") &&
		 !disallowMinus) {
	    currentToken = getNextToken();
	    FCExp rhs = parseTerm();
	    if (rhs == null)
		throw new 
		    FCParserException("Parse error after '-'", currentToken);
	    exp = new FCTimesExp(new FCAritTerm(-1), rhs);
	}


	return exp;
    }


    FCExp parseStatement() 	
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseStatement(): " + currentToken);

	FCExp st = null;

	if (currentToken.type == FCTokenType.SEPARATOR &&
	    currentToken.name.equals(";")) {
	    st = new FCEmptyExp();
	    currentToken = getNextToken();
	}
	else if (currentToken.type == FCTokenType.SEPARATOR &&
	    currentToken.name.equals("{")) {
	    currentToken = getNextToken();
	    st = parseBlock();
	}
	else if (currentToken.type == FCTokenType.KEYWORD &&
		 currentToken.name.equals("if")) {
	    currentToken = getNextToken();
	    st = parseIf();
	}
	else if (currentToken.type == FCTokenType.KEYWORD &&
		 currentToken.name.equals("while")) {
	    currentToken = getNextToken();
	    st = parseWhile();
	}
	else {
	    st = parseExp();
	    if (currentToken.type != FCTokenType.SEPARATOR ||
		!currentToken.name.equals(";")) {
		throw new
		    FCParserException("Missing expected ';'", currentToken);
	    }	    
	    currentToken = getNextToken();
	}

	endDeclarations = true;

	return st;
    }
	

    FCDeclExp parseDeclarations()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseDeclarations(): " + currentToken);

	String type;
	FCDeclExp res = null;
	FCExp ident;

	if (currentToken.type == FCTokenType.KEYWORD &&
	    FCSystemTables.typeTable.isKnownType(currentToken.name)) {
	    if (endDeclarations)
		throw new
		    FCParserException("Declaration not allowed here", 
				      currentToken);

	    type = currentToken.name;
	    currentToken = getNextToken();
	    if (currentToken.type != FCTokenType.IDENT)
		throw new FCParserException("Parse error after '" + 
					    currentToken.name + "'",
					    currentToken);
	    ident = new FCIdentTerm(currentToken.name);
	    currentToken = getNextToken();
	    if (currentToken.type == FCTokenType.OPERATOR &&
		currentToken.name.equals("=")) {
		currentToken = getNextToken();
		FCExp nextSeq = null;
		if ((nextSeq = parseE0()) == null)
		    throw new 
			FCParserException("Missing expected right hand side " +
					  "of declaration expression",
					  currentToken);
		res = new FCDeclExp(ident, nextSeq);
	    }
	    else 
		res = new FCDeclExp(ident, new FCAritTerm(0));
	
	    res.type = type;
	    if (currentToken.type != FCTokenType.SEPARATOR ||
		!currentToken.name.equals(";"))
		throw new
		    FCParserException("Missing expected ';'");
	    currentToken = getNextToken();
	}
	
	return res;
    }


    FCExp parseBlock()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseBlock(): " + currentToken);

	FCBlockExp be;
	FCDeclExp de;

	endDeclarations = false;

	be = new FCBlockExp();
	while ((de = parseDeclarations()) != null)
	    be.add(de);
	while (currentToken.type != FCTokenType.SEPARATOR ||
	       !currentToken.name.equals("}")) {
	    FCExp nextExp = parseStatement();
	    if (nextExp == null)
		return null;
	    be.add(nextExp);
	}
	currentToken = getNextToken();
	
	return be;
    }

    FCExp parseIf()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseIf(): " + currentToken);
	
	FCIfExp ifExp;
	if (currentToken.type != FCTokenType.SEPARATOR ||
	    !currentToken.name.equals("(")) {
	    throw new
		FCParserException("Missing expected '('", currentToken);
	}
	currentToken = getNextToken();
	FCExp cond = parseExp();
	if (cond == null)
	    return null;
	if (currentToken.type != FCTokenType.SEPARATOR ||
	    !currentToken.name.equals(")")) {
	    throw new
		FCParserException("Missing expected ')'", currentToken);
	}
	currentToken = getNextToken();

	ifExp = new FCIfExp(cond);
	FCExp action = parseStatement();
	if (action == null) {
	    throw new
		FCParserException("Parse error after ')'", currentToken);
	}
	    
	ifExp.setAction(action);
	
	if (currentToken.name.equals("else")) {
	    currentToken = getNextToken();
	    FCExp elseStat = parseElse();
	    if (elseStat == null) {
		throw new
		    FCParserException("Parse error after 'else'", 
				      currentToken);
	    }
	    ifExp.setElseStatement(elseStat);
	}

	return ifExp;
    }

    FCExp parseElse()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseElse(): " + currentToken);	

	FCExp elseExp = null;

	if (//currentToken.type == FCTokenType.KEYWORD
	    currentToken.name.equals("if")) {
	    currentToken = getNextToken();
	    elseExp = parseIf();
	}
	else
	    elseExp = parseStatement();

	return elseExp;
    }


    FCExp parseWhile()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseWhile(): " + currentToken);	
	
	FCWhileExp whileExp;
	if (currentToken.type != FCTokenType.SEPARATOR ||
	    !currentToken.name.equals("(")) {
	    throw new
		FCParserException("Missing expected '('", currentToken);
	}
	currentToken = getNextToken();
	FCExp cond = parseExp();
	if (cond == null)
	    return null;
	if (currentToken.type != FCTokenType.SEPARATOR ||
	    !currentToken.name.equals(")")) {
	    throw new
		FCParserException("Missing expected ')'", currentToken);
	}
	currentToken = getNextToken();
	
	whileExp = new FCWhileExp(cond);
	FCExp action = parseStatement();
	if (action == null) {
	    throw new
		FCParserException("Parse error after ')'", currentToken);
	}
	    
	whileExp.setAction(action);

	return whileExp;
    }
    

    FCExp parseExp() 
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseExp(): " + currentToken);

	FCExp exp = null;
	exp = parseE0();

	return exp;
    }


    FCExp parseCompilationUnit()
	throws FCException
    {
	if (FCOptions.debugParsing)
	    System.out.println("in parseCompilationUnit(): " + currentToken);

	FCExp exp = null;

	exp = parseDeclarations();
	if (exp != null)
	    return exp;

	exp = parseStatement();
	if (exp != null)
	    return exp;

	return exp;
    }

    /**
     * Il comportamento predefinito del parser � il seguente:
     *
     * recupera il prossimo token
     * prova a parsare l'espressione che ne inizia 
     * inserisci l'APT cos� ottenuto nel buffer condiviso col valutatore
     *
     * In caso di fine dei token:
     * 
     * inserisci un'espressione di tipo FCLastExp nel buffer condiviso col valutatore
     * prova a svegliare lexer e valutatore
     * esci
     *
     * In caso di errore:
     * 
     * salva il messaggio di errore
     * aggiorna il numero di errori
     * blocca il lexer
     * esegui le stesse operazione del caso fine token
     */
    public void run() {
	FCExp exp = null;
	boolean end = false;

	try {
	    currentToken = getNextToken();
	} 
	catch (FCException e) { 
	    end = true;
	}

	try {	
	    while(!(currentToken instanceof FCLastToken) && !stop) {

		exp = parseCompilationUnit();


		if (exp == null) {
		    System.out.println("Impossibile parsare l'espressione");
		    continue;
		}
		if (exp instanceof FCEmptyExp)
		    continue;
		
		bufferExp.put(exp);
	    }

	} catch (FCStopParsingException e) {
	    System.err.println("FIXME");
	} catch (FCException e) {
	    errorMsgs += e.getMessage();
	    errors++;
	    lexer.stop = true;
	}
	
	bufferExp.put(new FCLastExp());

	/* prima di uscire, prova a svegliare lexer e valutatore */
	   synchronized(bufferExp) {
	    bufferExp.notifyAll();
	}
	synchronized(bufferTok) {
	    bufferTok.notifyAll();
	}
	
	if (FCOptions.debugThread)
	    System.out.println("Parser exiting...");
    }
}	
