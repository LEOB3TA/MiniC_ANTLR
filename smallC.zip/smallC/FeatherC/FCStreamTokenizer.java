package FeatherC;

import java.io.StreamTokenizer;
import java.io.BufferedReader;

class FCStreamTokenizer
    extends FCLexer
{
    private StreamTokenizer st;
    private long linesRead = 0;

    public FCStreamTokenizer(java.io.Reader r, CircularBuffer buffer) 
	    throws java.io.IOException
    {
	super(buffer);
	st = new StreamTokenizer(r);
	setupSyntaxTable();
    }
    
    // servono per caricare plugin (altrimenti method not found durante
    // reflection)
    public FCStreamTokenizer(java.io.BufferedReader r, CircularBuffer buffer) 
	    throws java.io.IOException
    {
	super(buffer);
	st = new StreamTokenizer(r);
	setupSyntaxTable();
    }

    public FCStreamTokenizer(java.io.FileReader r, CircularBuffer buffer) 
	    throws java.io.IOException
    {
	super(buffer);
	st = new StreamTokenizer(r);
	setupSyntaxTable();
    }

    public FCStreamTokenizer(CircularBuffer buffer)
    {
	super(buffer);
    }

    public void setInput(java.io.Reader r)
    {
	st = new StreamTokenizer(r);
	setupSyntaxTable();
    }

    private void setupSyntaxTable() {

	// st.resetSyntax();
	st.ordinaryChar('+');
	st.ordinaryChar('*');
	st.ordinaryChar('/');
	st.ordinaryChar('%');
	st.ordinaryChar('&');
	st.ordinaryChar('|');
	st.ordinaryChar('!');
	st.ordinaryChar('(');
	st.ordinaryChar(')');
	st.ordinaryChar('[');
	st.ordinaryChar(']');
	st.ordinaryChar('.');
	st.ordinaryChar(',');
	st.ordinaryChar(';');
	st.ordinaryChar('<');
	st.ordinaryChar('>');
	st.ordinaryChar('=');
	st.ordinaryChar('?');
	st.ordinaryChar(':');
		
	st.commentChar('#');
	st.slashStarComments(true);
	st.slashSlashComments(true);

	st.whitespaceChars(0, ' ');
	st.eolIsSignificant(false);
	
	st.quoteChar('"');
	st.quoteChar('\'');
	
	/* NB:
	   queste vanno per ultime: le propriet� specificate da wordChars
	   e parseNumbers si sommano a quelle gi� possedute dai vari 
	   caratteri e non le sovrascrivono semplicemente!
	*/
	st.wordChars('_', '_');
	
	st.parseNumbers();
	// altrimenti 2-3 produce due soli token
	st.ordinaryChar('-');

    }

    private FCToken fillToken() 
    {
	FCToken tok = new FCToken();
	
	tok.lineno = st.lineno();
	
	switch(st.ttype) {

	case StreamTokenizer.TT_EOL:
	    if (FCOptions.debugToken)
		System.err.println("EOL received");
	    tok.type = FCTokenType.SPECIAL;
	    tok.name = st.sval;
	    break;
	    
	case StreamTokenizer.TT_EOF:
	    if (FCOptions.debugToken)
		System.err.println("EOF received");
	    return null;

	case StreamTokenizer.TT_WORD: 
	    tok.name = st.sval; 
	    if (tok.name.equals("null"))
		tok.type = FCTokenType.NULLLITERAL;
	    else if (tok.name.equals("true") || tok.name.equals("false"))
		tok.type = FCTokenType.BOOLLITERAL;
	    else if (FCSystemTables.keyTable.isKeyword(tok.name)) 
		tok.type = FCTokenType.KEYWORD;
	    else 
		tok.type = FCTokenType.IDENT;
	    break;

	    // non c'� modo di distinguere costanti intere da double usando il
	    // tokenizer di java.io!
	case StreamTokenizer.TT_NUMBER: 
	    tok.name = "" + st.nval;
	    tok.dvalue = st.nval;
	    tok.type = FCTokenType.FLOATLITERAL;
	    break;

	case '\'':
	    tok.name = st.sval;
	    tok.type = FCTokenType.CHARLITERAL;
	    break;

	case '"':
	    tok.name = st.sval;
	    tok.type = FCTokenType.STRINGLITERAL;
	    break;

	default:
	    tok.name = "" + (char) st.ttype;
	    if (FCSystemTables.sepTable.isSeparator(tok.name)) 
		tok.type = FCTokenType.SEPARATOR;
	    break;
	}

	return tok;
    }
    
	    


    public FCToken nextToken() 
	throws java.io.IOException	
    {
	assert st != null;

	int c = 0;
	try { c = st.nextToken();} 
	catch(java.io.IOException e) {
	    System.err.println(e + "\nstart");
	    return null;
	}
	
	FCToken tok = fillToken();

	if (tok == null) // EOF
	    return null;

	// update line information
	if (FCGeneral.currentLineNo != tok.lineno) {
	    FCGeneral.currentLineNo = tok.lineno;
	    if (in != null) 
		while (linesRead < tok.lineno) {
		    try {
			FCGeneral.currentLine = in.readLine();
		    } catch (java.io.IOException e) {}
		    linesRead++;
		}
	}

	
	if (tok.type == FCTokenType.UNSET) {
	    int nextc = 0;
	    
	    try { nextc = st.nextToken();} 
	    catch (java.io.IOException e) { 
		System.err.println(e + "unset");
		return tok;
		}

	    if (FCSystemTables.opTable.isOperator(tok.name)) {
		tok.type = FCTokenType.OPERATOR;

		// operatore composto di 2 caratteri?
		if (FCSystemTables.opTable.isOperator(tok.name+(char)nextc)){
		    tok.name += (char)nextc;

		    // operatore composto di 3 caratteri?
		    try { nextc = st.nextToken(); } 
		    catch (java.io.IOException e) { 
			System.err.println(e + "3");
			return tok;
			}
		    
		    if (FCSystemTables.opTable.isOperator(tok.name + (char)nextc)) 
			tok.name += (char)nextc;
		    else 
			st.pushBack();
		}
		else {
		    st.pushBack();
		}

	    }
	    
	}
	
	return tok;

    }

    public boolean checkToken(FCToken tok)
    {
	switch(tok.type) {
	case FCTokenType.CHARLITERAL: 
	    if (tok.name.length() > 1 && 
		! FCSystemTables.escSeqTable.isEscapeSequence(tok.name)){
		FCGeneral.emitError(tok, "not a valid char literal: " +
			  "\'" + tok.name + "\'");
		return false;
	    }
	}

	return true;
    }
}
