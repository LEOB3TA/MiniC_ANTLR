package FeatherC;


class FCStringValuator
    extends FCValuator
{
    public FCStringValuator(CircularBuffer b, FCParser p)
    {
	super(b, p);
    }

    public void visit(FCAritTerm e) 
    {
	res.add("" + e.value);
    }
    public void visit(FCBoolTerm e)
    {
	res.add("" + e.value);
    }
    public void visit(FCLessExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCLessEqualExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCGreaterExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCGreaterEqualExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCEqualExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCDifferentExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCPlusExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCMinusExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCTimesExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCDivideExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCModExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCAndExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCOrExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCNotExp e)
    {
	e.arg.accept(this);
	res.add("(" + e.getOp() + (String) getRes() + ")");
    }
    public void visit(FCAssignExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCDeclExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("(" + lres + e.getOp() + rres + ")");
    }
    public void visit(FCBlockExp e)
    {
	int i;
	String s = "";
	FCExp curExp;

	for (i = 0; i < e.statements.size(); i++) {
	    curExp = (FCExp) e.statements.elementAt(i);
	    curExp.accept(this);
	    s = s + (String) getRes();
	}
	
	res.add(s);
    }
    public void visit(FCIfExp e)
    {
	e.condition.accept(this);
	String condres = (String) getRes();
	e.action.accept(this);
	String actres = (String) getRes();
	String elseres = "";
	if (e.elseStatement != null) {
	    e.elseStatement.accept(this);
	    elseres = (String) getRes();
	}
	res.add("if (" + condres + ")\n" + actres + "\n" + elseres);
    }
    public void visit(FCWhileExp e)
    {
	e.condition.accept(this);
	String condres = (String) getRes();
	e.action.accept(this);
	String actres = (String) getRes();
	res.add("while (" + condres + ")\n" + actres + "\n");
    }
    public void visit(FCIdentTerm e)
    {
	res.add(e.name);
    }
    public void visit(FCIdentVal e)
    {
	res.add(e.name);
    }
}
