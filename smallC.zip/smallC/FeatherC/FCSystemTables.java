package FeatherC;

import java.util.HashMap;
import java.util.Vector;


class FCSeparatorTable
{
    private HashMap sepMap;
    private String[] seps = {"(", ")", "{", "}", "[", "]", ";", ",", "."};
    
    public FCSeparatorTable()
    {
	sepMap = new HashMap();
	
	int i;
	
	for (i = 0; i < seps.length; i++)
	    sepMap.put(seps[i], new Integer(i+1));
    }
    
    public boolean isSeparator(String s)
    {
	return sepMap.containsKey(s);
    }
    
    public boolean isSeparator(char c)
    {
	return isSeparator("" + c);
    }
}

class FCEscapeSequenceTable
{
    private HashMap seqMap;
    private String[] escSeq = 
    {"\\b", "\\t", "\\n", "\\f", "\\r", "\\\"", "\\'", "\\\\"};

    public FCEscapeSequenceTable() {
	seqMap = new HashMap();
	int i;

	for (i =0; i < escSeq.length; i++)
	    seqMap.put(escSeq[i], new Integer(i+1));
    }

    public boolean isEscapeSequence(String s)
    {
	return seqMap.containsKey(s);
    }
}
    
class FCOperatorTable
{
    private HashMap opMap;
    private String[] ops = 
	{"=", ">", "<", "!", "~", "?", ":",
	 "==", "<=", ">=", "!=", "&&", "||", "++", "--",
	 "+", "-", "*", "/", "&", "|", "^", "%", "<<", ">>", ">>>",
	 "+=", "-=", "*=", "/=", "&=", "|=", "^=", "%=", "<<=", ">>=", ">>>="
	 };
    

    public FCOperatorTable() 
    {
	opMap = new HashMap();
	int i;
	
	for (i = 0; i < ops.length; i++)
	    opMap.put(ops[i], new Integer(i+1));
    }
    
    public boolean isOperator(String s) 
    {
	return opMap.containsKey(s);
    }
    
    public boolean isOperator(char c)
    {
	return opMap.containsKey("" + c);
    }
    
    public int getOperatorNumber(String s) 
    {
	Integer val = (Integer) opMap.get(s);
	
	if (val == null)
	    return -1;
	
	return val.intValue();
    }
    
    public int getOperatorNumber(char c) 
    {
	return getOperatorNumber("" + c);
    }
}

class FCKeywordTable
{
    private HashMap keyMap;
    private String[] keys = {
	"auto", "break", "case", "char", "const", "continue", "default", "do", 
	"double", "else", "enum", "extern", "float", "for", "goto", "if", 
	"int", "long", "register", "return", "short", "signed", "sizeof", 
	"static", "struct", "switch", "typedef", "union", "unsigned", "void",
	"volatile", "while"
    };

    public FCKeywordTable()
    {
	keyMap = new HashMap();
	int i;
	
	for (i = 0; i < keys.length; i++)
	    keyMap.put(keys[i], new Integer(i+1));
    }	

    public boolean isKeyword(String s)
    {
	return keyMap.containsKey(s);
    }

    public int getKeywordNumber(String s)
    {
	Integer val = (Integer) keyMap.get(s);

	if (val == null)
	    return -1;

	return val.intValue();
    }
}

class FCKnownTypesTable
{
    private HashMap typeMap;
    private String[] types = {"int"};
    private int i;

    public FCKnownTypesTable()
    {
	typeMap = new HashMap();
	
	for (i = 0; i < types.length; i++)
	    typeMap.put(types[i], new Integer(i+1));
    }	

    public boolean isKnownType(String s)
    {    
	return typeMap.containsKey(s);
    }
    
    public void addKnownType(String s)
    {
	typeMap.put(s, new Integer(i+1));
	i++;
    }
	
}
	
class FCSystemTables 
{

    static FCOperatorTable opTable;
    static FCSeparatorTable sepTable;
    static FCEscapeSequenceTable escSeqTable;
    static FCKeywordTable keyTable;
    static FCKnownTypesTable typeTable;
    
    
    static void init() 
    {
	opTable = new FCOperatorTable();
	sepTable = new FCSeparatorTable();
	escSeqTable = new FCEscapeSequenceTable();
	keyTable = new FCKeywordTable();
	typeTable = new FCKnownTypesTable();
    }
}
