/**
 * Classi per la modellazione e gestione dei token
 *
 * @author Marco Cova (gennaio 2003)
 */


package FeatherC;

/**
 * FCToken
 *
 * Modella un token
 */
class FCToken 
{
    String name;    // il nome del token
    double dvalue;  // valore in caso di token reale
    int type;       // IDENT, OPERATOR, SLETTER, CONSTANT, SEPARATOR, KEYWORD
    long lineno;    // il numero di linea in cui trovato

    public FCToken(String n, int t, long l)
    {
	name = n;
	type = t;
	lineno = l;
    }
    
    public FCToken(String n, double dv, int t, long l)
    {
	this(n, t, l);
	dvalue = dv;
    }
    
    public FCToken()
    {
	this("", 0, FCTokenType.UNSET, -1);
    }
    
    
    public String toString() 
    {
	return name + "\t" + dvalue + "\t" + 
	    FCTokenType.toString(type) + "\t" + lineno;
    }

    public boolean isEofToken()
    {
	return type == FCTokenType.SPECIAL && name.equals("EOF");
    }

    public boolean isEosToken()
    {
	return type == FCTokenType.SEPARATOR && name.equals(";");
    }
}

class FCLastToken
    extends FCToken 
{

    public String toString() { return "Last token"; }
}

/**
 * FCTokenType
 *
 * Costanti per i diversi tipi di token conosciuti
 *
 */
class FCTokenType 
{
    static final int UNSET     = 0;
    static final int IDENT     = 1;
    static final int OPERATOR  = 2;
    static final int STRINGLITERAL = 3;
    static final int INTLITERAL  = 4;
    static final int FLOATLITERAL = 5;
    static final int BOOLLITERAL = 6;
    static final int NULLLITERAL = 7;
    static final int CHARLITERAL = 8;
    static final int KEYWORD   = 9;
    static final int SEPARATOR = 10;
    static final int SPECIAL = 11;
    
    static final String toString(int type) {
	switch(type) {
	case 0: return "UNSET";
	case 1: return "IDENT"; 
	case 2: return "OPERATOR"; 
	case 3: return "STRINGLITERAL";
	case 4: return "INTLITERAL";
	case 5: return "FLOATLITERAL";
	case 6: return "BOOLLITERAL";
	case 7: return "NULLLITERAL";
	case 8: return "CHARLITERAL";
	case 9: return "KEYWORD";
	case 10: return "SEPARATOR";
	case 11: return "SPECIAL";
	    
	default: return "ERROR";
	}
    }
}

/**
 * CircularBuffer
 *
 * Buffer circolare in cui i vari token sono inseriti (dal lexer) ed estratti
 * (dal parser) con logica FIFO
 *
 * Thread-safe
 *
 */
class CircularBuffer 
{
    private int head; // indice del primo elemento del buffer
    private int tail; // indice dell'ultimo elemento del buffer
    private int currentSize;
    private Object[] buffer;
    
    /**
     *
     * Crea un buffer con capacit� 20
     */
    public CircularBuffer() 
    {
	this(20);
    }

    /**
     *
     * Crea un buffer con la capacit� specificata    
     *
     * @param nelem numero di elementi che il buffer pu� contenere
     */
    public CircularBuffer(int nelem)
    {
	buffer = new Object[nelem];
	head = 0; tail = -1;
	currentSize = 0;
    }


    /**
     * Rimuove tutti gli elementi dal buffer
     */
    synchronized public void clear()
    {
	head = 0;
	tail = -1;
	currentSize = 0;
    }

    /**
     * get
     *
     * Estrae il primo elemento disponibile 
     * Se il buffer � vuoto, inserisce il thread corrente nella coda di wait 
     * Se il buffer era pieno, sveglia il primo thread della coda di wait
     *
     * @return il token estratto
     * 
     */    
    synchronized public Object get() 
    {
	assert (currentSize >= 0 && currentSize <= buffer.length):
	    currentSize;

	// non funziona: se thread1 wait qui e thread2 esce facendo una notify,
	// thread 1 continua a ciclare.
	// se semplice if, fallisce assert sottostante
	while (currentSize == 0) { // buffer vuoto
	    //	    System.err.println("HERE");
	    if (FCOptions.debugCircularBuffer)
		System.out.println("DEBUG: get wait" + "(" + currentSize + 
				   "/" + buffer.length + ")");

	    try { wait();} catch(InterruptedException e) { }
	}

	assert (currentSize > 0 && currentSize <= buffer.length):
	    currentSize;

	Object res = buffer[head];
	head = (head + 1) % buffer.length;
	if (FCOptions.debugCircularBuffer)
	    System.out.println("DEBUG: got " + res);
	
	if (currentSize-- == buffer.length) {
	    if (FCOptions.debugCircularBuffer)
		System.out.println("DEBUG: get notify");
	    notify();
	}
	
	return res;
    }
    

    /**
     * put 
     *
     * Inserisce l'elemento specificato
     * Se il buffer � pieno, inserisce il thread corrente nella coda di wait
     * Se il buffer era vuoto, sveglia il primo thread della coda di wait
     *
     * @param t il token da inserire nel buffer
     * 
     */
    synchronized public void put(Object t)
    {
	assert (currentSize >= 0 && currentSize <= buffer.length) :
	    currentSize;

	while (currentSize == buffer.length) { // buffer pieno
	    if (FCOptions.debugCircularBuffer)
		System.out.println("DEBUG: put wait (" + currentSize + 
				   "/" + buffer.length + ")");	    
	    try {wait();} catch(InterruptedException e) { }

	}
	
	tail = (tail + 1) % buffer.length;
	buffer[tail] = t;
	if (FCOptions.debugCircularBuffer)
	    System.out.println("DEBUG: put " + t);

	if (currentSize++ == 0) {
	    if (FCOptions.debugCircularBuffer)
		System.out.println("DEBUG: put notify");
	    notify();
	}
    }

    /**
     * toString
     *
     * Thread-safe: acquisisce il monitor dell'oggetto e raccoglie la 
     * descrizione degli elementi presenti nel buffer
     * @return una stringa che rappresenta il contenuto corrente del buffer 
     * (un elemento per riga)
     */
    public String toString() 
    {
	int j, i;
	String res = "";
	
	synchronized(this) {
	    assert (currentSize >= 0 && currentSize <= buffer.length) :
		currentSize;

	    for (j = 1, i = head; j <= currentSize; j++, i = (i+1)%buffer.length) 
		res = res + buffer[i] + "\n";
	}
	
	return res;
    }

    /**
     * isEmpty
     *
     * @return true se il buffer � correntemente (al momento in cui viene 
     * acquisito il monitor) vuoto, false altrimenti
     */
    synchronized public boolean isEmpty() 
    {
	assert (currentSize >= 0 && currentSize <= buffer.length) :
	    currentSize;

	return (currentSize == 0);
    }

    /**
     * count
     *
     * @return il numero di elementi correntemente contenuti nel buffer
     */
    synchronized public int count()
    {
	assert (currentSize >= 0 && currentSize <= buffer.length) :
	    currentSize;

	return currentSize;
    }

}


/* test classes
class FCTokenTest
{
    public static void main(String[] args) 
    {
	CircularBuffer FCTokenBuffer = new CircularBuffer(3);	
	Thread tGet = new FCLexerThread("get", FCTokenBuffer);
	Thread tPut = new FCLexerThread("put", FCTokenBuffer);
	
	tPut.start();
	tGet.start();
    }
    
}

class FCLexerThread extends Thread 
{
    CircularBuffer FCTokenBuffer;
    int ntoken = 0;
    
    FCLexerThread(String name, CircularBuffer b) 
    {
	super(name);
	FCTokenBuffer = b;
    }
    
    public void run() 
    {
	while (true) {
	    System.out.println(currentThread());
	    
	    
	    if (currentThread().getName().equals("get")) {
		if (ntoken >= 5 && FCTokenBuffer.isEmpty())
		    break;

		FCToken tok = (FCToken)FCTokenBuffer.get();
		ntoken = Integer.parseInt(tok.name);
	    }
	    else if (currentThread().getName().equals("put")){
		if (ntoken < 6) {
		    FCToken tok = new FCToken("" + ntoken, 0, 0);
		    ntoken++;
		    FCTokenBuffer.put(tok);
		    //		    System.out.println("Inserito: " + tok);
		}
		else 
		    break;
	    }
	    else
		System.out.println("***  unknown thread");
	    
	    System.out.println(FCTokenBuffer);
	}
    }
}

*/

