package FeatherC;

import java.util.Vector;
import java.util.HashMap;

/**
 * 
 * I valutatori sono realizzati seguendo il pattern 'visitor'
 * In questa interfaccia, i metodi che devono essere implementati dai vari
 * valutatori, che devono quindi essere in grado di valuatare le seguenti
 * espressioni:
 * FCAritTerm
 * FCBoolTerm
 * FCLessEqualExp
 * FCGreaterExp
 * FCGreaterEqualExp
 * FCEqualExp
 * FCDifferentExp
 * FCPlusExp
 * FCMinusExp
 * FCTimesExp
 * FCDivideExp
 * FCModExp
 * FCAndExp
 * FCOrExp
 * FCNotExp
 * FCAssignExp
 * FCIdentTerm
 * FCIdentVal
 * FCBlockExp
 * FCIfExp
 * FCDeclExp
 * FCWhileExp
 */
interface IFCVisitor 
{
    void visit(FCAritTerm e);
    void visit(FCBoolTerm e);
    void visit(FCLessExp e);
    void visit(FCLessEqualExp e);
    void visit(FCGreaterExp e);
    void visit(FCGreaterEqualExp e);
    void visit(FCEqualExp e);
    void visit(FCDifferentExp e);
    void visit(FCPlusExp e);
    void visit(FCMinusExp e);
    void visit(FCTimesExp e);
    void visit(FCDivideExp e);
    void visit(FCModExp e);
    void visit(FCAndExp e);
    void visit(FCOrExp e);
    void visit(FCNotExp e);
    void visit(FCAssignExp e);
    void visit(FCIdentTerm e);
    void visit(FCIdentVal e);
    void visit(FCBlockExp e);
    void visit(FCIfExp e);
    void visit(FCDeclExp e);
    void visit(FCWhileExp e);
}

/**
 * Classe astratta che deve essere estesa dai valutatori di SmallC<br>
 * <br>
 * In generale un valutatore:<br>
 * <ul>
 *     <li>� associato ad un thread</li>
 *     <li>estrae espressioni dal buffer condiviso col parser</li>
 *     <li>genera le valutazioni</li>
 * </ul>
 */
public abstract class FCValuator
    extends Thread
    implements IFCVisitor
{
    /**
     * Il buffer circolare condiviso col parser
     */
    private CircularBuffer buffer;

    /** 
     * Contiene le valutazioni dell'espressione corrente.
     * Egrave; ricorrere ad un Vector perch� alcune espressioni (e.g. FCBlockExp)
     * possono generare pi� d'una valutazione
     */
    protected Vector res;

    /**
     * Numero di errori ravvisati
     */
    protected int errors = 0;

    /**
     * Messaggio di errore
     */
    protected String errorMsgs = "";

    /**
     * Flag che indica quando � necessario fermarsi
     * Il parser lo setta a true in caso di errori
     */
    boolean stop = false;

    /**
     * Il parser. Usato solo per segnalare eventuali errori e bloccarlo.
     */
    FCParser parser;

    /**
     * Vettore contenente tutte le valutazioni prodotte.
     */
    protected Vector evalVector;

    /**
     * HashMap contenente le variabili globali e i loro valori
     */
    protected HashMap globalEnv;

    /**
     * @param buffer il buffer condiviso con il parser
     * @param parser il parser
     */
    public FCValuator(CircularBuffer buffer, FCParser parser) {
	super("Evaluator");

	assert buffer != null && parser != null;

	this.parser = parser;
	this.buffer = buffer;
	evalVector = new Vector();
	globalEnv = new HashMap();
	res = new Vector();
    }

    /**
     * Restituisce il numero di errori ravvisati dal valutatore
     */
    public int getErrors() { return errors;}

    /**
     * @return una stringa contenente la descrizione degli errori trovati
     */
    public String getErrorMsgs() { return errorMsgs; }

    /**
     * @return un Vector contenente la valutazione delle espressioni valutate
     */
    public Vector getEvaluations() { return evalVector; }

    /**
     * @return un array associativo rappresentate l'environment globale al 
     * cos� come questo era al termine della valutazione
     */
    public HashMap getGlobalEnv() { return globalEnv; }

    /**
     * Formatta le valutazioni
     */
    protected void formatEvaluations() {}

    /**
     * Permette di eseguire un fixup prima dell'uscita del valutatore
     */
    protected void onExit() {}

    /**
     * Recupera l'ultima valutazione prodotta
     *
     * @return l'ultima valutazione prodotta.
     */
    Object getRes() {
	/*	Object o =  res.remove(res.size() - 1);
	System.out.println("getRes(): " + o);
	return o;*/
	assert res.size() > 0;
	
	return res.remove(res.size() - 1);
    };

    /**
     * Estrae dal buffer condiviso col parser la prossima espressione
     */
    FCExp getNextExp()
    {
	return (FCExp) buffer.get();
    }

    /**
     * Entry point del valutatore.
     *
     * Finch� non si verifica un errore o non sono terminate le espressioni
     * da valutare:
     * <ul>
     *     <li>visita l'espressione corrente
     *     <li>inserisci nel vettore delle valutazioni la valutazione dell'espressione corrente
     * </ul>
     * <br>
     * Prima di uscire:
     * <ul>
     *    <li>chiama onExit
     *    <li>chiama formatEvaluations    
     * </ul>
     */
    public void run()
    {
	FCExp currentExp;

	while (!((currentExp = getNextExp()) instanceof FCLastExp) && !stop) {
	    assert (currentExp != null) : buffer.count();

	    currentExp.accept(this);

	    //System.out.println("Espressione valutata: " + getRes());
	    for (int i = 0; i < res.size(); i++)
		evalVector.add(res.elementAt(i));
	    res.clear();
	}
	
	onExit();

	formatEvaluations();

	if (FCOptions.debugThread)
	    System.out.println("Evaluator exiting...");
    }
}
	


