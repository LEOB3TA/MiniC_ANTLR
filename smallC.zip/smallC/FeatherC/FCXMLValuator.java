package FeatherC;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.ContentHandler;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXException;

import java.io.StringReader;

import java.util.Vector;

class FCXMLValuator
    extends FCValuator
{
    private SAXParserFactory factory;
    private SAXParser saxParser;
    private final String docName = "FCCPROG";

    public FCXMLValuator(CircularBuffer b, FCParser p)
    {
	super(b, p);
	try {
	    factory = SAXParserFactory.newInstance();
	    saxParser = factory.newSAXParser();
	} catch (javax.xml.parsers.FactoryConfigurationError e) {
	} catch (javax.xml.parsers.ParserConfigurationException e) {
	} catch (org.xml.sax.SAXException e) {}
	//saxParser.getXMLReader().setContentHandler(new FCXMLContentHandler());
	evalVector.add("<"+ docName + ">");
    }


    public void visit(FCAritTerm e) 
    {
	res.add("<ARITTERM>" +  e.value + "</ARITTERM>");
    }
    public void visit(FCBoolTerm e)
    {
	res.add("<BOOLTERM>" + e.value + "</BOOLTERM>");
    }
    public void visit(FCLessExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<LESSEXP>" + lres + rres + "</LESSEXP>");
    }
    public void visit(FCLessEqualExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<LESSEQUAL>" + lres + rres + "</LESSEQUAL>");
    }
    public void visit(FCGreaterExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<GREATEREXP>" + lres + rres + "</GREATEREXP>");
    }
    public void visit(FCGreaterEqualExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<GREATEREQUAL>" + lres + rres + "</GREATEREQUAL>");
    }
    public void visit(FCEqualExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<EQUAL>" + lres + rres + "</EQUAL>");
    }
    public void visit(FCDifferentExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<DIFFERENT>" + lres + rres + "</DIFFERENT>");
    }
    public void visit(FCPlusExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<PLUSEXP>" + lres + rres + "</PLUSEXP>");
    }
    public void visit(FCMinusExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<MINUSEXP>" + lres + rres + "</MINUSEXP>");
    }
    public void visit(FCTimesExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<TIMESEXP>" + lres + rres + "</TIMESEXP>");
    }
    public void visit(FCDivideExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<DIVIDEEXP>" + lres + rres + "</DIVIDEEXP>");
    }
    public void visit(FCModExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<MODEXP>" + lres + rres + "</MODEXP>");
    }
    public void visit(FCAndExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<ANDEXP>" + lres + rres + "</ANDEXP>");
    }
    public void visit(FCOrExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<OREXP>" + lres + rres + "</OREXP>");
    }
    public void visit(FCNotExp e)
    {
	e.arg.accept(this);
	res.add("<NOTEXP>" + (String) getRes() + "</NOTEXP>");
    }
    public void visit(FCAssignExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<ASSIGNEXP>" + lres + rres + "</ASSIGNEXP>");
    }
    public void visit(FCDeclExp e)
    {
	e.left.accept(this); 
	String lres = (String) getRes();
	e.right.accept(this);
	String rres = (String) getRes();
	res.add("<DECLARATION>" + lres + rres + "</DECLARATION>");
    }
    public void visit(FCBlockExp e)
    {
	int i;
	String s = "";
	FCExp curExp;

	for (i = 0; i < e.statements.size(); i++) {
	    curExp = (FCExp) e.statements.elementAt(i);
	    curExp.accept(this);
	    s = s + (String) getRes();
	}
	
	res.add("<BLOCKEXP>" + s + "</BLOCKEXP>");
    }
    public void visit(FCIfExp e)
    {
	e.condition.accept(this);
	String condres = (String) getRes();
	e.action.accept(this);
	String actres = (String) getRes();
	String elseres = "";
	if (e.elseStatement != null) {
	    e.elseStatement.accept(this);
	    elseres = (String) getRes();
	}
	res.add("<IFEXP><IFCOND>" + condres + "</IFCOND>" + "<IFSTAT>" + 
		actres + "</IFSTAT>" + (elseres.equals("")? "" : "<ELSEEXP>" + elseres + "</ELSEEXP>") + "</IFEXP>");
    }
    public void visit(FCWhileExp e)
    {
	e.condition.accept(this);
	String condres = (String) getRes();
	e.action.accept(this);
	String actres = (String) getRes();
	res.add("<WHILEEXP><WHILECOND>" + condres + "</WHILECOND>" + 
		"<WHILESTAT>" + actres + "</WHILESTAT>" + "</WHILEEXP>");
    }
    public void visit(FCIdentTerm e)
    {
	res.add("<IDENTTERM>" + e.name + "</IDENTTERM>");
    }
    public void visit(FCIdentVal e)
    {
	res.add("<IDENTVAL>" + e.name + "</IDENTVAL>");
    }

    protected void formatEvaluations() 
    {
	String s = "";
	for (int i = 0; i < evalVector.size(); i++)
	    s = s + evalVector.elementAt(i);
	s = s + "\n";
	InputSource in = new InputSource(new StringReader(s));

	try {
	    saxParser.parse(in, new FCXMLContentHandler(evalVector));
	} catch (org.xml.sax.SAXParseException e) {
	    System.err.println("An error occured while parsing the XML doc: " +
			       e + ": " + e.getLineNumber() + "." + 
			       e.getColumnNumber());
	} catch (Exception e) {}

    }

    protected void onExit() 
    {
	evalVector.add("</" + docName + ">");
    }
}


class FCXMLContentHandler
    extends DefaultHandler
{
    private int indentLevel = 0;
    private Vector v;
    String s = "";

    FCXMLContentHandler(Vector v) 
    {
	v.clear();
	this.v = v;
    }

    public void startElement(String uri, String localName, String qName,
			     org.xml.sax.Attributes attributes)
	throws SAXException
    {
	for (int i = 0; i < indentLevel; i++)
	    s += "\t";

	s += "<" + qName + ">\n";
	indentLevel++;
    }

    public void endElement(String uri, String localName, String qName)
	throws SAXException
    {
	indentLevel--;

	for (int i = 0; i < indentLevel; i++)
	    s = s + "\t";

	s += "</" + qName + ">\n";
    }

    public void characters(char[] ch, int start, int length) {
	for (int i = 0; i < indentLevel; i++)
	    s = s + "\t";

	s += new String(ch, start, length) + "\n";
    }

    public void endDocument() {
	v.add(s);
    }
    public void startDocument() {
	s += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"+
	    "<!DOCTYPE FCCPROG SYSTEM \"smallc.dtd\">\n";
    }

}
	
