package FeatherC;


import java.io.*;
import java.util.Vector;

public class Fcc1 {
    public static void main(String[] args) {
	SmallC engine = new SmallC();
	SolveInfo solInfo = null;
	Vector filesIn = new Vector();
	Vector fileNames = new Vector();
	boolean debugToken = false; boolean debugBuffer = false;
	boolean debugParsing= false; boolean debugThread = false;
	boolean debugEval= false;
	boolean quiet = false;
	String evalPluginName = "FCEvalValuator";
	String lexerPluginName = "FCStreamTokenizer"; 

	/* analisi degli argomenti della linea di comando */
	int i = 0;
	while (i < args.length) {
	    if (args[i].equals("--eval-plugin") ||
		args[i].equals("-E")) 
		evalPluginName = args[++i];
	    else if (args[i].equals("--lexer-plugin") ||
		     args[i].equals("-L")) 
		lexerPluginName = args[++i];
	    else if (args[i].equals("--xml"))
		evalPluginName = "FCXMLValuator";
	    else if (args[i].equals("--string"))
		evalPluginName = "FCStringValuator";
	    else if (args[i].equals("--eval"))
		evalPluginName = "FCEvalValuator";
	    else if (args[i].equals("--dgtoken") ||
		     args[i].equals("-t"))
		debugToken = true;
	    else if (args[i].equals("--dbbuffer") ||
		     args[i].equals("-b"))
		debugBuffer = true;
	    else if (args[i].equals("--dbparsing") ||
		     args[i].equals("-p"))
		debugParsing = true;			 
	    else if (args[i].equals("--dbthread") ||
		     args[i].equals("-T"))
		debugThread = true;
	    else if (args[i].equals("--dbeval") ||
		     args[i].equals("-e"))
		debugEval = true;
	    else if (args[i].equals("--quiet") ||
		     args[i].equals("-q"))
		quiet = true;
	    else if (args[i].equals("--help") ||
		     args[i].equals("-h")) {
		print_help();
		System.exit(0);
	    }
	    else if (args[i].equals("--version") ||
		     args[i].equals("-v")) {
		print_version();
		System.exit(0);
	    }
	    else if (args[i].charAt(0) == '-') {
		System.out.println("Opzione sconosciuta: " + args[i] + ".\n" +
				   "-h per l'elenco delle opzioni valide");
		System.exit(1);
	    }
	    else {  // filename
		fileNames.add(args[i]);
		
		try {
		    filesIn.add(new BufferedReader(new FileReader(args[i])));
		} catch (FileNotFoundException e) {
		    System.err.println("Non posso aprire il file " + e.getMessage());
		    System.exit(2);
		}
	    }

	    i++;
	}

	if (filesIn.isEmpty()) {
	    filesIn.add(new BufferedReader(new InputStreamReader(System.in)));
	    fileNames.add("stdin");
	}


	/* parametri dell'engine */
	engine.setDebugOptions(debugToken, debugBuffer, debugParsing,
			       debugThread, debugEval);

	engine.setLexerPlugin("FeatherC." + lexerPluginName);
	engine.setEvalPlugin("FeatherC." + evalPluginName);
	
	/* solve query */
	for (i = 0; i < filesIn.size(); i++) {
	    if (!quiet)
		System.out.println("Interpreto " + fileNames.elementAt(i) + "...");

	    solInfo = engine.solve((Reader)filesIn.elementAt(i));

	    if (solInfo.isSuccess()) {
		Vector sol = solInfo.getEvaluations();
		if (!quiet)
		    System.out.println("Espressioni valutate:");
		for (int j = 0; j < sol.size(); j++)
		    System.out.println(sol.elementAt(j));
	    }
	    else
		System.out.println("***There were errors:\n" +
				   solInfo.getErrorMsgs());
	}
    }

    private static void print_help() {
	System.out.println("`Fcc1' interpreta il filename specificato (default: stdin)\n\n" +
			   "Uso: Fcc1 [OPZIONI]... [filename]\n\n" + 
			   //			   "OPZIONI valide:\n" + 
			   "-E, --eval-plugin plugin    usa il valutatore implementato da `plugin'\n" +
			   "--xml                       uguale a -E FCXMLValuator\n" +
			   "--string                    uguale a -E FCStringValuator\n" +
			   "--eval                      uguale a -E FCEvalValuator\n" +
			   "-L, --lexer-plugin plugin   usa il lexer implementato da `plugin'\n" +
			   "-t, --dbtoken               attiva il debug dei token\n" +
			   "-b, --dbbuffer              attiva il debug del buffer circolare\n" +
			   "-p, --dbparsing             attiva il debug del parser\n" +
			   "-T, --dbthread              attiva il debug dei thread\n" +
			   "-e, --dbeval                attiva il debug del valutatore\n" +
			   "--quiet                     stampa solo il risultato della valutazione\n" +
			   "-v, --version               stampa la versione e esci\n" + 
			   "-h, --help                  stampa questo messaggio e esci");
    }

    static void print_version()
    {
	System.out.println("Fcc1 1.0\n\n" +
			   "This is free software. There is NO warranty etc." +
			   "\n\nWritten by Marco Cova <marco.cova@studio.unibo.it>");
    }

}

	    
	
