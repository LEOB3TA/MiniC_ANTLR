package FeatherC;

import java.io.*;
import java.lang.reflect.*;
import java.util.HashMap;
import java.util.Vector;



/**
 * Componente che incapsula lexer, parser e valutatore di un linguaggio
 * sottoinsieme del linguaggio C.
 * <br><br>
 * Tipico scenario d'uso:<br>
 * <pre>
 * 	SmallC engine = new SmallC();
 *      SolveInfo solInfo = engine.solve(new BufferedReader(
 *                                       new FileReader("file.txt")));
 * 
 *	if (solInfo.isSuccess()) {
 *	  Vector sol = solInfo.getEvaluations();
 *
 *	  for (int j = 0; j < sol.size(); j++)
 *	    System.out.println(sol.elementAt(j));
 *      }
 *      else
 *	  System.out.println("***There were errors:\n" + 
 *                           solInfo.getErrorMsgs());
 *</pre>
 */
public class SmallC
{
    private CircularBuffer bufTok;
    private CircularBuffer bufExp;
    private FCLexer l;
    private FCParser p;
    private FCValuator v;
    private String evalPluginName = "default";
    private String lexerPluginName = "default";

    /**
     * Crea un nuovo engine di interpretazione del linguaggio.
     * <br><br>
     * Per default, ogni tipo di debug � disattivato, 
     * il lexer � FCStreamTokenizer e il valutatore � FCEvalValuator
     */
    public SmallC() {
	bufTok = new CircularBuffer();
	bufExp = new CircularBuffer();

	FCSystemTables.init();
    }

    /**
     * Imposta il livello di debug.
     *
     * @param debugToken attiva il debugging a livello di token
     * @param debugBuffer attiva il debug dei buffer
     * @param debugParsing attiva il debug del parsing
     * @param debugThread attiva il debug dei thread
     * @param debugEval attiva il debug del valutatore
     */
    public void setDebugOptions(boolean debugToken, boolean debugBuffer,
				boolean debugParsing, boolean debugThread,
				boolean debugEval) {
	FCOptions.debugToken = debugToken;
	FCOptions.debugCircularBuffer = debugBuffer;
	FCOptions.debugParsing = debugParsing;			 
	FCOptions.debugThread = debugThread;
	FCOptions.debugEval = debugEval;
    }

    /**
     * Imposta il plugin da usare come valutatore.
     *
     * @param pluginName basename del file in cui � contenuta l'implementazione
     *                   del plugin
     * @see FCValuator
     */
    public void setEvalPlugin(String pluginName) {
	evalPluginName = pluginName;
    }

    /** 
     * Imposta il plugin da usare come lexer.
     *
     * @param pluginName basename del file in cui � contenuta l'implementazione
     *                   del plugin
     * @see FCLexer
     */
    public void setLexerPlugin(String pluginName) {
	lexerPluginName = pluginName;
    }

    /**
     * Interpreta un programma.
     *
     * @param s stringa contenente il programma da interpretare
     * @return tutte le informazioni riguardanti l'interpretazioni wrapped in
     *         oggetto di classe SolveInfo 
     * @see SolveInfo
     */
    public SolveInfo solve(String s) {
	return solve(new StringReader(s));
    }
    
    /**
     * Interpreta un programma.
     *
     * @param in Reader contenente il programma da interpretare
     * @return tutte le informazioni riguardanti l'interpretazioni wrapped in
     *         oggetto di classe SolveInfo 
     * @see SolveInfo
     */
    public SolveInfo solve(Reader in) {
	/* re-init buffers */
	bufTok.clear();
	bufExp.clear();

	if (!lexerPluginName.equals("default")) {
	    Object[] lexerInitArgs = {bufTok};
	    Object plugin = loadPlugin(lexerPluginName, lexerInitArgs);
	    checkLexerPlugin(plugin);
	    l = (FCLexer) plugin;
	}
	else 
	    l = new FCStreamTokenizer(bufTok);

	p = new FCParser(bufTok, bufExp, l);

	if (!evalPluginName.equals("default")) {
	    Object[] evalInitArgs = {bufExp, p};
	    Object plugin = loadPlugin(evalPluginName, evalInitArgs);
	    checkEvalPlugin(plugin);
	    v = (FCValuator) plugin;
	}
	else
	    v = new FCEvalValuator(bufExp, p);

	l.setInput(in);
	return solve();
    }

    private SolveInfo solve() {
	l.start();
	p.start();
	v.start();

	try {
	    v.join();
	    p.join();
	    l.join();
	} catch(InterruptedException e) {System.err.println("QUI");}
	
	assert !v.isAlive() && !p.isAlive() && !l.isAlive();

	SolveInfo solution = new SolveInfo(v.getEvaluations(), 
					   v.getGlobalEnv());
	solution.success = v.getErrors() == 0 && 
	                   p.getErrors() == 0 && 
	                   l.getErrors() == 0;
	if (!solution.success)
	    solution.errorMsgs = "Lexer errors: " + l.getErrorMsgs() + "\n" +
		"Parser errors: " + p.getErrorMsgs() + "\n" + 
		"Valuator errors: " +  v.getErrorMsgs();
	else
	    solution.errorMsgs = "No errors.";
		

	return solution;
    }	

    /**
     * Carica un plugin
     *
     * @param className il nome della classe da caricare
     * @param initArgs array degli argomenti da passare al costruttore
     */
    private Object loadPlugin(String className, Object[] initArgs) 
    {
	Class evalPlugin = null;
	Object p = null;

	try {
	    evalPlugin = Class.forName(className);
	} catch (Exception e) {
	    System.err.println("Non riesco a caricare il plugin " + 
			       className);
	    System.exit(10);
	}

	Constructor constructor = null;	
	Class[] parameters = new Class[initArgs.length];
	
	for (int i = 0; i < initArgs.length; i++) {
	    parameters[i] = initArgs[i].getClass();
	}
	
	try {
	    constructor = evalPlugin.getConstructor(parameters);
	    p = constructor.newInstance(initArgs);
	} catch (Exception e) {
	    System.err.println("Invalid plugin");
	    System.exit(11);
	}
	
	return p;
    }

    private void checkEvalPlugin(Object p)
    {
	if (!(p instanceof FCValuator)) {
	    System.err.println("Not a valid implementation of an evaluator plugin");
	    System.exit(12);
	}
    }

    private void checkLexerPlugin(Object p)
    {
	if (!(p instanceof FCLexer)) {
	    System.err.println("Not a valid implementation of a lexer plugin");
	    System.exit(13);
	}
    }
}
