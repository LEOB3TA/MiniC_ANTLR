package FeatherC;

import java.util.Vector;
import java.util.HashMap;

/**
 * Wrapper per il risultato della valutazione di un programma.
 *
 */
public class SolveInfo
{
    private Vector evalVector;
    private HashMap environment;
    protected boolean success;
    protected String errorMsgs = "";

    public SolveInfo(Vector evalVector) {
	this(evalVector, null);
    }
    public SolveInfo(Vector evalVector, HashMap environment) {
	this.evalVector = evalVector;
	this.environment = environment;
    }

    /**
     * Esamina se l'interpretazione si � conclusa con successo.
     *
     * @return true se l'interpretazione si � conclusa con successo, false altrimenti 
     */
    public boolean isSuccess() {
	return success;
    }

    /**
     * In caso di interpretazione conclusasi con successo, recupera il 
     * risultato della valutazione.
     *
     * @return un Vector contenente tutte le valutazioni prodotte dal valutatore
     */
    public Vector getEvaluations() {
	return evalVector;
    }

    /**
     * In caso di interpretazione conclusasi con successo, recupera il valore
     * di una variabile definita nell'environment globale.
     *
     * @param s il nome di una variable definita nell'environment globale del programma
     * @return il valore della variabile al termine della valutazione
     */
    public Object getVariable(String s) {
	if (environment == null)
	    return null;

	return environment.get(s);
    }

    /**
     * In caso di interpretazione conclusasi con insuccesso, recupera la
     * descrizione degli errori.
     *
     * @return stringa contenente i messaggi degli errori avvenuti durante l'interpretazione
     */
    public String getErrorMsgs() {
	return errorMsgs;
    }
}
