int main(void) 
{

	int a = 2;

	{
		int a = 5;
		printf("%d\n", 10 + a);
		a = 3;
		printf("%d\n", 10 + a);
	}

	printf("%d\n", 10 + a);
}

