int main(void)
{
	int a = 2;

	{
		a = 5;
		printf("%d\n", 10 + a); 
		{
			int a = 7;
			printf("%d\n", 10 + a);
		}
		printf("%d\n", 10 + a);
	}
printf("%d\n", 10 + a);
}

